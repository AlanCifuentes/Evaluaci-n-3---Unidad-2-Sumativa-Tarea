class Departamento:
    """Departamento con gerente y lista de empleados asociados."""

    def __init__(self, id, nombre, gerente=None, lista_empleados=None):
        self.id = id
        self.nombre = nombre
        self.gerente = gerente
        self.lista_empleados = list(lista_empleados or [])

    @property
    def id(self):
        return self._id

    @id.setter
    def id(self, valor):
        self._id = self._requerido(valor, "El ID")

    @property
    def nombre(self):
        return self._nombre

    @nombre.setter
    def nombre(self, valor):
        self._nombre = self._requerido(valor, "El nombre")

    @property
    def gerente(self):
        return self._gerente

    @gerente.setter
    def gerente(self, valor):
        if valor is not None and not hasattr(valor, "id"):
            raise TypeError("El gerente debe ser un objeto Empleado o None.")
        self._gerente = valor

    @property
    def lista_empleados(self):
        # Retorna una copia para evitar modificar la colección sin validación.
        return tuple(self._lista_empleados)

    @lista_empleados.setter
    def lista_empleados(self, valor):
        self._lista_empleados = list(valor)

    @staticmethod
    def _requerido(valor, campo):
        """Valida que un dato de texto obligatorio no esté vacío."""
        if not isinstance(valor, str) or not valor.strip():
            raise ValueError(f"{campo} no puede estar vacío.")
        return valor.strip()

    def verificar_disponibilidad(self, empleado):
        """Un empleado puede estar en este departamento si no pertenece a otro."""
        return empleado.departamento_id in (None, self.id)

    def agregar_empleado(self, empleado):
        """Asocia un empleado disponible al departamento."""
        if not self.verificar_disponibilidad(empleado):
            raise ValueError("El empleado ya pertenece a otro departamento.")
        if all(actual.id != empleado.id for actual in self._lista_empleados):
            self._lista_empleados.append(empleado)
        empleado.departamento_id = self.id

    def contar_empleados(self):
        """Devuelve la cantidad de empleados asociados."""
        return len(self._lista_empleados)

    def __str__(self):
        """Entrega una representación legible del departamento."""
        return f"Departamento: {self.nombre} | Empleados: {self.contar_empleados()}"
