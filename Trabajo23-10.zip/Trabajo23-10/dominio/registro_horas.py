from datetime import date
from uuid import uuid4


class RegistroHoras:
    """Horas trabajadas por un empleado en un proyecto."""

    def __init__(self, id, fecha, horas_trabajadas, descripcion_tarea,
                 empleado_id, proyecto_id):
        """Inicializa un registro y verifica sus datos obligatorios."""
        self.id = id or str(uuid4())
        self.fecha = fecha
        self.horas_trabajadas = horas_trabajadas
        self.descripcion_tarea = descripcion_tarea
        self.empleado_id = empleado_id
        # Puede quedar sin proyecto si este se elimina; la agregación permite
        # conservar el registro histórico.
        self.proyecto_id = (
            self._requerido(proyecto_id, "El ID del proyecto")
            if proyecto_id is not None else None
        )
        if not self.validar_horas():
            raise ValueError("Las horas trabajadas deben ser mayores que cero.")

    @property
    def id(self):
        return self._id

    @id.setter
    def id(self, valor):
        self._id = self._requerido(str(valor), "El ID")

    @property
    def fecha(self):
        return self._fecha

    @fecha.setter
    def fecha(self, valor):
        if not isinstance(valor, date):
            raise TypeError("La fecha debe ser un objeto date.")
        self._fecha = valor

    @property
    def horas_trabajadas(self):
        return self._horas_trabajadas

    @horas_trabajadas.setter
    def horas_trabajadas(self, valor):
        if isinstance(valor, bool) or not isinstance(valor, int):
            raise TypeError("Las horas trabajadas deben ser un número entero.")
        if valor <= 0:
            raise ValueError("Las horas trabajadas deben ser mayores que cero.")
        self._horas_trabajadas = valor

    @property
    def descripcion_tarea(self):
        return self._descripcion_tarea

    @descripcion_tarea.setter
    def descripcion_tarea(self, valor):
        self._descripcion_tarea = self._requerido(valor, "La descripción")

    @property
    def empleado_id(self):
        return self._empleado_id

    @empleado_id.setter
    def empleado_id(self, valor):
        self._empleado_id = self._requerido(valor, "El ID del empleado")

    @property
    def proyecto_id(self):
        return self._proyecto_id

    @proyecto_id.setter
    def proyecto_id(self, valor):
        self._proyecto_id = (
            self._requerido(valor, "El ID del proyecto")
            if valor is not None else None
        )

    @staticmethod
    def _requerido(valor, campo):
        if not isinstance(valor, str) or not valor.strip():
            raise ValueError(f"{campo} no puede estar vacío.")
        return valor.strip()

    def validar_horas(self):
        """Indica si el registro contiene una cantidad positiva de horas."""
        horas_es_entero = isinstance(self.horas_trabajadas, int)
        no_es_booleano = not isinstance(self.horas_trabajadas, bool)
        return horas_es_entero and no_es_booleano and self.horas_trabajadas > 0

    def calcular_total_horas(self):
        """Devuelve las horas de este registro."""
        return self.horas_trabajadas

    def __str__(self):
        """Entrega una representación legible del registro."""
        return (
            f"RegistroHoras {self.id}: {self.horas_trabajadas} h "
            f"(empleado {self.empleado_id})"
        )

    def __repr__(self):
        return (
            f"RegistroHoras(id={self.id!r}, fecha={self.fecha!r}, "
            f"horas_trabajadas={self.horas_trabajadas!r}, "
            f"empleado_id={self.empleado_id!r}, proyecto_id={self.proyecto_id!r})"
        )
