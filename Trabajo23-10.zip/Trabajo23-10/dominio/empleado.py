from datetime import date
import math
import re


def normalizar_rut(valor):
    """Valida el dígito verificador y devuelve el RUT canónico sin puntos."""
    if not isinstance(valor, str):
        raise TypeError("El RUT debe ingresarse como texto.")

    rut = re.sub(r"\s+", "", valor).upper()
    if rut.count("-") > 1:
        raise ValueError("Formato de RUT inválido.")

    if "-" in rut:
        base, digito_ingresado = rut.split("-")
    else:
        compacto = rut.replace(".", "")
        if len(compacto) < 2:
            raise ValueError("El RUT debe incluir cuerpo y dígito verificador.")
        base, digito_ingresado = compacto[:-1], compacto[-1]

    if "." in base:
        if not re.fullmatch(r"\d{1,3}(?:\.\d{3})+", base):
            raise ValueError("Los puntos del RUT deben separar grupos de miles.")
        base = base.replace(".", "")
    elif not base.isdigit():
        raise ValueError("El cuerpo del RUT debe contener solo números.")

    if not base or len(base) > 8 or int(base) == 0:
        raise ValueError("El cuerpo del RUT no tiene un largo válido.")
    base = str(int(base))  # Quita ceros iniciales para usar una forma única.

    if len(digito_ingresado) != 1 or digito_ingresado not in "0123456789K":
        raise ValueError("El dígito verificador del RUT no es válido.")

    suma = 0
    factor = 2
    for digito in reversed(base):
        suma += int(digito) * factor
        factor = 2 if factor == 7 else factor + 1
    resultado = 11 - (suma % 11)
    esperado = "0" if resultado == 11 else "K" if resultado == 10 else str(resultado)

    if digito_ingresado != esperado:
        raise ValueError("El RUT no es válido: revisa su dígito verificador.")
    return f"{base}-{esperado}"


class Empleado:
    """Trabajador de EcoTech; sus atributos reflejan el UML."""

    def __init__(self, id, nombre, direccion, telefono, email,
                 fecha_inicio_contrato, salario, departamento_id=None):
        """Inicializa un empleado y sus relaciones en memoria."""
        self.id = id
        self.nombre = nombre
        self.direccion = direccion
        self.telefono = telefono
        self.email = email
        self.fecha_inicio_contrato = fecha_inicio_contrato
        self.salario = salario
        # Referencias que materializan las relaciones UML en memoria.
        self.departamento_id = departamento_id
        self._registros_horas = []
        self._proyectos = []

    @property
    def id(self):
        return self._id

    @id.setter
    def id(self, valor):
        self._id = normalizar_rut(valor)

    @property
    def nombre(self):
        return self._nombre

    @nombre.setter
    def nombre(self, valor):
        self._nombre = self._texto_requerido(valor, "El nombre")

    @property
    def direccion(self):
        return self._direccion

    @direccion.setter
    def direccion(self, valor):
        self._direccion = self._texto_requerido(valor, "La dirección")

    @property
    def telefono(self):
        return self._telefono

    @telefono.setter
    def telefono(self, valor):
        self._telefono = self._texto_requerido(valor, "El teléfono")

    @property
    def email(self):
        return self._email

    @email.setter
    def email(self, valor):
        self._email = self._texto_requerido(valor, "El email")

    @property
    def fecha_inicio_contrato(self):
        return self._fecha_inicio_contrato

    @fecha_inicio_contrato.setter
    def fecha_inicio_contrato(self, valor):
        if not isinstance(valor, date):
            raise TypeError("La fecha de inicio debe ser un objeto date.")
        self._fecha_inicio_contrato = valor

    @property
    def salario(self):
        return self._salario

    @salario.setter
    def salario(self, valor):
        if isinstance(valor, bool) or not isinstance(valor, (int, float)):
            raise TypeError("El salario debe ser numérico.")
        if not math.isfinite(float(valor)) or valor < 0:
            raise ValueError("El salario no puede ser negativo.")
        if not float(valor).is_integer():
            raise ValueError("El salario debe ingresarse en pesos enteros, sin decimales.")
        self._salario = float(valor)

    @property
    def departamento_id(self):
        return self._departamento_id

    @departamento_id.setter
    def departamento_id(self, valor):
        if valor is not None and (not isinstance(valor, str) or not valor.strip()):
            raise ValueError("El ID del departamento debe ser texto no vacío o None.")
        self._departamento_id = valor.strip() if isinstance(valor, str) else None

    @property
    def registros_horas(self):
        return tuple(self._registros_horas)

    @property
    def proyectos(self):
        return tuple(self._proyectos)

    @staticmethod
    def _texto_requerido(valor, campo):
        if not isinstance(valor, str) or not valor.strip():
            raise ValueError(f"{campo} no puede estar vacío.")
        return valor.strip()

    def calcular_horas_totales(self):
        """Calcula las horas de los registros asociados al empleado."""
        return sum(registro.calcular_total_horas() for registro in self.registros_horas)

    def validar_contacto(self):
        """Indica si el teléfono y el email tienen un formato básico válido."""
        email_valido = re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", self.email)
        telefono_valido = re.fullmatch(r"[+0-9()\-\s]{7,20}", self.telefono)
        return bool(email_valido and telefono_valido)

    def get_id(self):
        """Devuelve el identificador del empleado, que corresponde a su RUT."""
        return self.id

    def agregar_registro_horas(self, registro):
        """Agrega un registro si todavía no está asociado al empleado."""
        if all(actual.id != registro.id for actual in self._registros_horas):
            self._registros_horas.append(registro)

    def agregar_proyecto(self, proyecto):
        """Agrega un proyecto a la relación muchos-a-muchos."""
        if all(actual.id != proyecto.id for actual in self._proyectos):
            self._proyectos.append(proyecto)

    def __str__(self):
        """Entrega una representación legible del empleado."""
        return f"Empleado: {self.nombre} | RUT: {self.id}"

    def __repr__(self):
        return (f"Empleado(id={self.id!r}, nombre={self.nombre!r}, "
                f"fecha_inicio_contrato={self.fecha_inicio_contrato!r}, "
                f"salario={self.salario!r})")
