class Proyecto:
    """Proyecto y sus asociaciones con empleados y registros de horas."""

    def __init__(self, id, nombre, descripcion, fecha_inicio,
                 empleados=None, registros_horas=None):
        self.id = id
        self.nombre = nombre
        self.descripcion = descripcion
        self.fecha_inicio = fecha_inicio
        self.empleados = list(empleados or [])
        self.registros_horas = list(registros_horas or [])

    @property
    def id(self):
        return self._id

    @id.setter
    def id(self, valor):
        self._id = self._requerido(valor, "El ID")

    @property
    def nombre(self):
        return self._nombre

    @nombre.setter
    def nombre(self, valor):
        self._nombre = self._requerido(valor, "El nombre")

    @property
    def descripcion(self):
        return self._descripcion

    @descripcion.setter
    def descripcion(self, valor):
        self._descripcion = self._requerido(valor, "La descripción")

    @property
    def fecha_inicio(self):
        return self._fecha_inicio

    @fecha_inicio.setter
    def fecha_inicio(self, valor):
        from datetime import date
        if not isinstance(valor, date):
            raise TypeError("La fecha de inicio debe ser un objeto date.")
        self._fecha_inicio = valor

    @property
    def empleados(self):
        return tuple(self._empleados)

    @empleados.setter
    def empleados(self, valor):
        self._empleados = list(valor)

    @property
    def registros_horas(self):
        return tuple(self._registros_horas)

    @registros_horas.setter
    def registros_horas(self, valor):
        self._registros_horas = list(valor)

    @staticmethod
    def _requerido(valor, campo):
        """Valida que un dato de texto obligatorio no esté vacío."""
        if not isinstance(valor, str) or not valor.strip():
            raise ValueError(f"{campo} no puede estar vacío.")
        return valor.strip()

    def contar_empleados_asignados(self):
        """Devuelve la cantidad de empleados asignados al proyecto."""
        return len(self.empleados)

    def asignar_empleado(self, empleado):
        """Asocia un empleado al proyecto sin duplicar la relación."""
        if all(actual.id != empleado.id for actual in self._empleados):
            self._empleados.append(empleado)
        empleado.agregar_proyecto(self)

    def agregar_registro_horas(self, registro):
        """Agrega un registro de horas sin duplicarlo."""
        if all(actual.id != registro.id for actual in self._registros_horas):
            self._registros_horas.append(registro)

    def __str__(self):
        """Entrega una representación legible del proyecto."""
        return f"Proyecto: {self.nombre} | Empleados: {self.contar_empleados_asignados()}"
