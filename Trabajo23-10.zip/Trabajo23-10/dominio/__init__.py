"""Clases del dominio EcoTech."""
