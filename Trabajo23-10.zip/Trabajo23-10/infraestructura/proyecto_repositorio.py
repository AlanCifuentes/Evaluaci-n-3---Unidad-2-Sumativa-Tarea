from datetime import date
from dominio.proyecto import Proyecto
from dominio.registro_horas import RegistroHoras
from infraestructura.conexion import obtener_conexion
from infraestructura.empleado_repositorio import EmpleadoRepositorio


class ProyectoRepositorio:
    def guardar(self, proyecto):
        with obtener_conexion() as conn:
            conn.execute(
                """INSERT INTO proyecto
                   (id, nombre, descripcion, fecha_inicio)
                   VALUES (?, ?, ?, ?)""",
                (proyecto.id, proyecto.nombre, proyecto.descripcion,
                 proyecto.fecha_inicio.isoformat()),
            )
        return proyecto

    def _fila_a_proyecto(self, conn, fila):
        proyecto = Proyecto(fila["id"], fila["nombre"], fila["descripcion"],
                            date.fromisoformat(fila["fecha_inicio"]))
        employees = conn.execute("""
            SELECT e.* FROM empleado e
            JOIN empleado_proyecto ep ON ep.empleado_id = e.id
            WHERE ep.proyecto_id = ? ORDER BY e.nombre
        """, (proyecto.id,)).fetchall()
        proyecto.empleados = [EmpleadoRepositorio._fila_a_empleado(conn, e) for e in employees]
        rows = conn.execute("SELECT * FROM registro_horas WHERE proyecto_id = ? ORDER BY fecha",
                            (proyecto.id,)).fetchall()
        for r in rows:
            proyecto.agregar_registro_horas(RegistroHoras(
                r["id"], date.fromisoformat(r["fecha"]), r["horas_trabajadas"],
                r["descripcion_tarea"], r["empleado_id"], r["proyecto_id"]))
        return proyecto

    def obtener(self, id):
        with obtener_conexion() as conn:
            fila = conn.execute("SELECT * FROM proyecto WHERE id = ?", (id,)).fetchone()
            return self._fila_a_proyecto(conn, fila) if fila else None

    def listar(self):
        with obtener_conexion() as conn:
            filas = conn.execute("SELECT * FROM proyecto ORDER BY nombre").fetchall()
            return [self._fila_a_proyecto(conn, f) for f in filas]

    def actualizar(self, proyecto):
        with obtener_conexion() as conn:
            cur = conn.execute("""
                UPDATE proyecto SET nombre = ?, descripcion = ?, fecha_inicio = ? WHERE id = ?
            """, (proyecto.nombre, proyecto.descripcion,
                  proyecto.fecha_inicio.isoformat(), proyecto.id))
            return cur.rowcount

    def asignar_empleado(self, proyecto_id, empleado_id):
        with obtener_conexion() as conn:
            conn.execute("INSERT INTO empleado_proyecto (empleado_id, proyecto_id) VALUES (?, ?)",
                         (empleado_id, proyecto_id))
        return True

    def desasignar_empleado(self, proyecto_id, empleado_id):
        with obtener_conexion() as conn:
            cur = conn.execute(
                """DELETE FROM empleado_proyecto
                   WHERE empleado_id = ? AND proyecto_id = ?""",
                (empleado_id, proyecto_id),
            )
            return cur.rowcount > 0

    def eliminar(self, id):
        with obtener_conexion() as conn:
            cur = conn.execute("DELETE FROM proyecto WHERE id = ?", (id,))
            return cur.rowcount > 0
