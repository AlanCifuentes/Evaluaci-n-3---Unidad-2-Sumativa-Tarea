from contextlib import contextmanager
import os
from pathlib import Path
import sqlite3

DB_PATH = Path(os.environ.get(
    "ECOTECH_DB_PATH",
    Path(__file__).resolve().parent.parent / "ecotech_validada.db"
))


@contextmanager
def obtener_conexion():
    """Abre una conexión SQLite, habilita claves foráneas y siempre la cierra."""
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def crear_tablas(conn):
    """Crea las tablas y relaciones correspondientes al UML."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS departamento (
            id TEXT PRIMARY KEY,
            nombre TEXT NOT NULL,
            gerente_id TEXT REFERENCES empleado(id) ON DELETE SET NULL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS empleado (
            id TEXT PRIMARY KEY,
            nombre TEXT NOT NULL,
            direccion TEXT NOT NULL,
            telefono TEXT NOT NULL,
            email TEXT NOT NULL,
            fecha_inicio_contrato TEXT NOT NULL,
            salario REAL NOT NULL CHECK (salario >= 0),
            departamento_id TEXT NOT NULL REFERENCES departamento(id) ON DELETE RESTRICT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS proyecto (
            id TEXT PRIMARY KEY,
            nombre TEXT NOT NULL,
            descripcion TEXT NOT NULL,
            fecha_inicio TEXT NOT NULL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS empleado_proyecto (
            empleado_id TEXT NOT NULL REFERENCES empleado(id) ON DELETE CASCADE,
            proyecto_id TEXT NOT NULL REFERENCES proyecto(id) ON DELETE CASCADE,
            PRIMARY KEY (empleado_id, proyecto_id)
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS registro_horas (
            id TEXT PRIMARY KEY,
            fecha TEXT NOT NULL,
            horas_trabajadas INTEGER NOT NULL CHECK (horas_trabajadas > 0),
            descripcion_tarea TEXT NOT NULL,
            empleado_id TEXT NOT NULL REFERENCES empleado(id) ON DELETE CASCADE,
            proyecto_id TEXT REFERENCES proyecto(id) ON DELETE SET NULL
        )
    """)
