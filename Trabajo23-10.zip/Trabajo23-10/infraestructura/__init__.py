"""Persistencia SQLite y repositorios EcoTech."""
