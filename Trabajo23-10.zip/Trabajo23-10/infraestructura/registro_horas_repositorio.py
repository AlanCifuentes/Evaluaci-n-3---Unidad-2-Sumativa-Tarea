from datetime import date
from dominio.registro_horas import RegistroHoras
from infraestructura.conexion import obtener_conexion


class RegistroHorasRepositorio:
    def guardar(self, registro):
        with obtener_conexion() as conn:
            conn.execute("""
                INSERT INTO registro_horas
                (id, fecha, horas_trabajadas, descripcion_tarea, empleado_id, proyecto_id)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (registro.id, registro.fecha.isoformat(), registro.horas_trabajadas,
                  registro.descripcion_tarea, registro.empleado_id, registro.proyecto_id))
        return registro

    @staticmethod
    def _fila_a_registro(fila):
        return RegistroHoras(fila["id"], date.fromisoformat(fila["fecha"]),
                             fila["horas_trabajadas"], fila["descripcion_tarea"],
                             fila["empleado_id"], fila["proyecto_id"])

    def obtener(self, id):
        with obtener_conexion() as conn:
            fila = conn.execute("SELECT * FROM registro_horas WHERE id = ?", (id,)).fetchone()
            return self._fila_a_registro(fila) if fila else None

    def listar(self, empleado_id=None, proyecto_id=None):
        sql = "SELECT * FROM registro_horas WHERE 1 = 1"
        params = []
        if empleado_id is not None:
            sql += " AND empleado_id = ?"
            params.append(empleado_id)
        if proyecto_id is not None:
            sql += " AND proyecto_id = ?"
            params.append(proyecto_id)
        sql += " ORDER BY fecha"
        with obtener_conexion() as conn:
            return [self._fila_a_registro(f) for f in conn.execute(sql, params).fetchall()]

    def actualizar(self, registro):
        with obtener_conexion() as conn:
            cur = conn.execute("""
                UPDATE registro_horas SET fecha = ?, horas_trabajadas = ?,
                    descripcion_tarea = ?, empleado_id = ?, proyecto_id = ? WHERE id = ?
            """, (registro.fecha.isoformat(), registro.horas_trabajadas,
                  registro.descripcion_tarea, registro.empleado_id,
                  registro.proyecto_id, registro.id))
            return cur.rowcount

    def eliminar(self, id):
        with obtener_conexion() as conn:
            cur = conn.execute("DELETE FROM registro_horas WHERE id = ?", (id,))
            return cur.rowcount > 0
