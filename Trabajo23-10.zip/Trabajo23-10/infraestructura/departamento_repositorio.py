from datetime import date
from dominio.departamento import Departamento
from dominio.empleado import Empleado
from infraestructura.conexion import obtener_conexion
from infraestructura.empleado_repositorio import EmpleadoRepositorio


class DepartamentoRepositorio:
    def guardar(self, departamento):
        gerente_id = departamento.gerente.id if departamento.gerente else None
        with obtener_conexion() as conn:
            conn.execute("INSERT INTO departamento (id, nombre, gerente_id) VALUES (?, ?, ?)",
                         (departamento.id, departamento.nombre, gerente_id))
        return departamento

    def _fila_a_departamento(self, conn, fila):
        gerente = None
        if fila["gerente_id"]:
            manager_row = conn.execute("SELECT * FROM empleado WHERE id = ?",
                                       (fila["gerente_id"],)).fetchone()
            if manager_row:
                gerente = EmpleadoRepositorio._fila_a_empleado(conn, manager_row)
        empleados = []
        rows = conn.execute("SELECT * FROM empleado WHERE departamento_id = ?",
                            (fila["id"],)).fetchall()
        empleados = [EmpleadoRepositorio._fila_a_empleado(conn, r) for r in rows]
        return Departamento(fila["id"], fila["nombre"], gerente, empleados)

    def obtener(self, id):
        with obtener_conexion() as conn:
            fila = conn.execute("SELECT * FROM departamento WHERE id = ?", (id,)).fetchone()
            return self._fila_a_departamento(conn, fila) if fila else None

    def listar(self):
        with obtener_conexion() as conn:
            filas = conn.execute("SELECT * FROM departamento ORDER BY nombre").fetchall()
            return [self._fila_a_departamento(conn, f) for f in filas]

    def actualizar(self, departamento):
        gerente_id = departamento.gerente.id if departamento.gerente else None
        with obtener_conexion() as conn:
            cur = conn.execute("UPDATE departamento SET nombre = ?, gerente_id = ? WHERE id = ?",
                               (departamento.nombre, gerente_id, departamento.id))
            return cur.rowcount

    def asignar_empleado(self, departamento_id, empleado_id):
        with obtener_conexion() as conn:
            row = conn.execute("SELECT departamento_id FROM empleado WHERE id = ?",
                               (empleado_id,)).fetchone()
            if row is None:
                raise ValueError("No existe ese empleado.")
            if row["departamento_id"] not in (None, departamento_id):
                raise ValueError("El empleado ya pertenece a otro departamento.")
            cur = conn.execute("UPDATE empleado SET departamento_id = ? WHERE id = ?",
                               (departamento_id, empleado_id))
            return cur.rowcount > 0

    def establecer_gerente(self, departamento_id, empleado_id):
        with obtener_conexion() as conn:
            row = conn.execute("SELECT departamento_id FROM empleado WHERE id = ?",
                               (empleado_id,)).fetchone()
            if row is None or row["departamento_id"] != departamento_id:
                raise ValueError("El gerente debe ser un empleado del departamento.")
            cur = conn.execute("UPDATE departamento SET gerente_id = ? WHERE id = ?",
                               (empleado_id, departamento_id))
            return cur.rowcount > 0

    def eliminar(self, id):
        with obtener_conexion() as conn:
            cur = conn.execute("DELETE FROM departamento WHERE id = ?", (id,))
            return cur.rowcount > 0
