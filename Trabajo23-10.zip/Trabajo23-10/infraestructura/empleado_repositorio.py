from datetime import date
import sqlite3
from dominio.empleado import Empleado
from dominio.registro_horas import RegistroHoras
from dominio.proyecto import Proyecto
from infraestructura.conexion import obtener_conexion


class EmpleadoRepositorio:
    def guardar(self, empleado):
        if not empleado.validar_contacto():
            raise ValueError("El teléfono o el email del empleado no son válidos.")
        with obtener_conexion() as conn:
            conn.execute("""
                INSERT INTO empleado
                (id, nombre, direccion, telefono, email, fecha_inicio_contrato,
                 salario, departamento_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (empleado.id, empleado.nombre, empleado.direccion,
                  empleado.telefono, empleado.email,
                  empleado.fecha_inicio_contrato.isoformat(), empleado.salario,
                  empleado.departamento_id))
        return empleado

    @staticmethod
    def _fila_a_empleado(conn, fila):
        empleado = Empleado(
            id=fila["id"], nombre=fila["nombre"], direccion=fila["direccion"],
            telefono=fila["telefono"], email=fila["email"],
            fecha_inicio_contrato=date.fromisoformat(fila["fecha_inicio_contrato"]),
            salario=fila["salario"], departamento_id=fila["departamento_id"])
        for r in conn.execute(
            "SELECT * FROM registro_horas WHERE empleado_id = ? ORDER BY fecha",
            (empleado.id,)
        ).fetchall():
            empleado.agregar_registro_horas(RegistroHoras(
                r["id"], date.fromisoformat(r["fecha"]), r["horas_trabajadas"],
                r["descripcion_tarea"], r["empleado_id"], r["proyecto_id"]))
        for p in conn.execute("""
            SELECT p.* FROM proyecto p
            JOIN empleado_proyecto ep ON ep.proyecto_id = p.id
            WHERE ep.empleado_id = ?
        """, (empleado.id,)).fetchall():
            empleado.agregar_proyecto(Proyecto(
                p["id"], p["nombre"], p["descripcion"],
                date.fromisoformat(p["fecha_inicio"])))
        return empleado

    def obtener(self, id):
        with obtener_conexion() as conn:
            fila = conn.execute("SELECT * FROM empleado WHERE id = ?", (id,)).fetchone()
            return self._fila_a_empleado(conn, fila) if fila else None

    def listar(self):
        with obtener_conexion() as conn:
            filas = conn.execute("SELECT * FROM empleado ORDER BY nombre").fetchall()
            return [self._fila_a_empleado(conn, fila) for fila in filas]

    def actualizar(self, empleado):
        if not empleado.validar_contacto():
            raise ValueError("El teléfono o el email del empleado no son válidos.")
        with obtener_conexion() as conn:
            cur = conn.execute("""
                UPDATE empleado SET nombre = ?, direccion = ?, telefono = ?,
                    email = ?, fecha_inicio_contrato = ?, salario = ?,
                    departamento_id = ? WHERE id = ?
            """, (empleado.nombre, empleado.direccion, empleado.telefono,
                  empleado.email, empleado.fecha_inicio_contrato.isoformat(),
                  empleado.salario, empleado.departamento_id, empleado.id))
            return cur.rowcount

    def eliminar(self, id):
        with obtener_conexion() as conn:
            cur = conn.execute("DELETE FROM empleado WHERE id = ?", (id,))
            return cur.rowcount > 0
