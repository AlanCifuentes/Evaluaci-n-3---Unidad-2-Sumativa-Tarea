from datetime import date
import sqlite3
import sys

from dominio.departamento import Departamento
from dominio.empleado import Empleado, normalizar_rut
from dominio.proyecto import Proyecto
from dominio.registro_horas import RegistroHoras
from infraestructura.conexion import crear_tablas, obtener_conexion
from infraestructura.departamento_repositorio import DepartamentoRepositorio
from infraestructura.empleado_repositorio import EmpleadoRepositorio
from infraestructura.proyecto_repositorio import ProyectoRepositorio
from infraestructura.registro_horas_repositorio import RegistroHorasRepositorio


def inicializar():
    with obtener_conexion() as conn:
        crear_tablas(conn)


def leer_texto(mensaje):
    valor = input(mensaje).strip()
    if not valor:
        raise ValueError("Este campo no puede quedar vacío.")
    return valor


def leer_fecha(mensaje):
    valor = leer_texto(mensaje)
    try:
        return date.fromisoformat(valor)
    except ValueError as error:
        raise ValueError("Usa el formato de fecha AAAA-MM-DD.") from error


def leer_salario(mensaje):
    valor = leer_texto(mensaje)
    if not valor.isascii() or not valor.isdigit():
        raise ValueError(
            "Ingresa el salario en pesos enteros, solo con dígitos "
            "(ejemplo: 950000; sin puntos, comas ni decimales)."
        )
    return float(int(valor))


def leer_rut(mensaje):
    return normalizar_rut(leer_texto(mensaje))


def leer_entero_positivo(mensaje):
    valor = leer_texto(mensaje)
    try:
        numero = int(valor)
    except ValueError as error:
        raise ValueError("Ingresa un número entero.") from error
    if numero <= 0:
        raise ValueError("El valor debe ser mayor que cero.")
    return numero


def generar_rut_de_prueba():
    """Genera un RUT de prueba único para la demostración automática."""
    from uuid import uuid4
    base = str(uuid4().int % 90_000_000 + 10_000_000)
    suma = 0
    factor = 2
    for digito in reversed(base):
        suma += int(digito) * factor
        factor = 2 if factor == 7 else factor + 1
    verificador = 11 - (suma % 11)
    dv = "0" if verificador == 11 else "K" if verificador == 10 else str(verificador)
    return f"{base}-{dv}"


def mostrar_menu():
    print("""
=== EcoTech: Gestión de empleados ===
1. Crear departamento
2. Asignar gerente a departamento
3. Crear empleado
4. Crear proyecto
5. Asignar empleado a proyecto
6. Registrar horas
7. Consultar datos
8. Actualizar salario de empleado
9. Actualizar registro de horas
10. Actualizar proyecto
11. Actualizar departamento
12. Eliminar registro de horas
13. Eliminar empleado
14. Eliminar proyecto
15. Eliminar departamento
0. Salir
""")


def ejecutar_menu():
    departamentos = DepartamentoRepositorio()
    empleados = EmpleadoRepositorio()
    proyectos = ProyectoRepositorio()
    registros = RegistroHorasRepositorio()

    while True:
        mostrar_menu()
        opcion = input("Elige una opción: ").strip()
        try:
            if opcion == "0":
                print("Hasta luego.")
                return
            elif opcion == "1":
                depto = Departamento(leer_texto("ID del departamento: "),
                                     leer_texto("Nombre: "))
                departamentos.guardar(depto)
                print("Departamento creado.")
            elif opcion == "2":
                dept_id = leer_texto("ID del departamento: ")
                emp_id = leer_texto("ID del empleado gerente: ")
                departamentos.establecer_gerente(dept_id, emp_id)
                print("Gerente asignado.")
            elif opcion == "3":
                dept_id = leer_texto("ID del departamento: ")
                if departamentos.obtener(dept_id) is None:
                    raise ValueError("No existe ese departamento.")
                emp = Empleado(
                    leer_rut("RUT (ej. 12.345.678-5 o 123456785): "),
                    leer_texto("Nombre: "),
                    leer_texto("Dirección: "),
                    leer_texto("Teléfono: "),
                    leer_texto("Email: "),
                    leer_fecha("Fecha de contrato (AAAA-MM-DD): "),
                    leer_salario("Salario en pesos enteros (ej. 950000): "),
                    dept_id,
                )
                empleados.guardar(emp)
                print("Empleado creado.")
            elif opcion == "4":
                proyecto = Proyecto(
                    leer_texto("ID del proyecto: "),
                    leer_texto("Nombre: "),
                    leer_texto("Descripción: "),
                    leer_fecha("Fecha de inicio (AAAA-MM-DD): "),
                )
                proyectos.guardar(proyecto)
                print("Proyecto creado.")
            elif opcion == "5":
                project_id = leer_texto("ID del proyecto: ")
                employee_id = leer_texto("ID del empleado: ")
                proyectos.asignar_empleado(project_id, employee_id)
                print("Empleado asignado al proyecto.")
            elif opcion == "6":
                registro = RegistroHoras(
                    None,
                    leer_fecha("Fecha (AAAA-MM-DD): "),
                    leer_entero_positivo("Horas trabajadas (entero): "),
                    leer_texto("Descripción de la tarea: "),
                    leer_texto("ID del empleado: "),
                    leer_texto("ID del proyecto: "),
                )
                registros.guardar(registro)
                print(f"Registro creado con ID {registro.id}.")
            elif opcion == "7":
                print("Empleados:")
                for emp in empleados.listar():
                    print(f"  {emp.id} | {emp.nombre} | {emp.email} | salario={emp.salario}")
                print("Departamentos:")
                for depto in departamentos.listar():
                    gerente_id = depto.gerente.id if depto.gerente else "sin gerente"
                    print(
                        f"  {depto.id} | {depto.nombre} | gerente={gerente_id} "
                        f"| empleados={depto.contar_empleados()}"
                    )
                print("Proyectos:")
                for proyecto in proyectos.listar():
                    print(
                        f"  {proyecto.id} | {proyecto.nombre} "
                        f"| empleados={proyecto.contar_empleados_asignados()}"
                    )
                print("Registros de horas:")
                for registro in registros.listar():
                    print(
                        f"  {registro.id} | empleado={registro.empleado_id} "
                        f"| proyecto={registro.proyecto_id} "
                        f"| horas={registro.horas_trabajadas}"
                    )
            elif opcion == "8":
                emp_id = leer_texto("ID del empleado: ")
                emp = empleados.obtener(emp_id)
                if emp is None:
                    print("No se encontró el empleado.")
                else:
                    emp.salario = leer_salario("Nuevo salario en pesos enteros (ej. 950000): ")
                    empleados.actualizar(emp)
                    print("Salario actualizado.")
            elif opcion == "9":
                record_id = leer_texto("ID del registro: ")
                registro = registros.obtener(record_id)
                if registro is None:
                    print("No se encontró el registro.")
                else:
                    registro.horas_trabajadas = leer_entero_positivo("Nuevo total de horas: ")
                    registros.actualizar(registro)
                    print("Registro actualizado.")
            elif opcion == "10":
                project_id = leer_texto("ID del proyecto: ")
                proyecto = proyectos.obtener(project_id)
                if proyecto is None:
                    print("No se encontró el proyecto.")
                else:
                    proyecto.nombre = leer_texto("Nuevo nombre: ")
                    proyecto.descripcion = leer_texto("Nueva descripción: ")
                    proyecto.fecha_inicio = leer_fecha("Nueva fecha (AAAA-MM-DD): ")
                    proyectos.actualizar(proyecto)
                    print("Proyecto actualizado.")
            elif opcion == "11":
                dept_id = leer_texto("ID del departamento: ")
                depto = departamentos.obtener(dept_id)
                if depto is None:
                    print("No se encontró el departamento.")
                else:
                    depto.nombre = leer_texto("Nuevo nombre: ")
                    departamentos.actualizar(depto)
                    print("Departamento actualizado.")
            elif opcion == "12":
                print("Registro eliminado." if registros.eliminar(leer_texto("ID del registro: "))
                      else "No se encontró el registro.")
            elif opcion == "13":
                print("Empleado eliminado." if empleados.eliminar(leer_texto("ID del empleado: "))
                      else "No se encontró el empleado.")
            elif opcion == "14":
                print("Proyecto eliminado; sus registros históricos se conservan." 
                      if proyectos.eliminar(leer_texto("ID del proyecto: "))
                      else "No se encontró el proyecto.")
            elif opcion == "15":
                eliminado = departamentos.eliminar(
                    leer_texto("ID del departamento: ")
                )
                print(
                    "Departamento eliminado."
                    if eliminado else "No se encontró el departamento."
                )
            else:
                print("Opción no reconocida.")
        except (ValueError, TypeError) as error:
            print(f"Dato inválido: {error}")
        except sqlite3.IntegrityError as error:
            print(f"No se pudo completar por una relación o dato duplicado: {error}")
        except sqlite3.Error as error:
            print(f"Error de base de datos: {error}")


def demostracion_crud():
    """Prueba breve para comprobar CRUD y relaciones con datos temporales."""
    from uuid import uuid4
    sufijo = uuid4().hex[:8]
    dept_id, project_id = f"dep-{sufijo}", f"proy-{sufijo}"
    emp_id = generar_rut_de_prueba()
    dept_repo = DepartamentoRepositorio()
    emp_repo = EmpleadoRepositorio()
    project_repo = ProyectoRepositorio()
    hours_repo = RegistroHorasRepositorio()

    departamento = Departamento(dept_id, "Operaciones")
    dept_repo.guardar(departamento)
    empleado = Empleado(emp_id, "Ana Rojas", "Av. Central 123", "+56 9 1234 5678",
                        "ana.rojas@ecotech.cl", date.today(), 950000.0, dept_id)
    emp_repo.guardar(empleado)
    departamento.gerente = empleado
    dept_repo.establecer_gerente(dept_id, emp_id)
    proyecto = Proyecto(project_id, "Paneles solares", "Instalación de paneles", date.today())
    project_repo.guardar(proyecto)
    project_repo.asignar_empleado(project_id, emp_id)
    registro = RegistroHoras(None, date.today(), 8, "Instalación y revisión", emp_id, project_id)
    hours_repo.guardar(registro)

    encontrado = emp_repo.obtener(emp_id)
    print("Empleado leído:", encontrado)
    print("Contacto válido:", encontrado.validar_contacto())
    print("Horas totales:", encontrado.calcular_horas_totales())
    print("Empleados del departamento:", dept_repo.obtener(dept_id).contar_empleados())
    print("Empleados del proyecto:", project_repo.obtener(project_id).contar_empleados_asignados())

    encontrado.salario = 980000.0
    emp_repo.actualizar(encontrado)
    registro.horas_trabajadas = 7
    hours_repo.actualizar(registro)
    print("Registro actualizado:", hours_repo.obtener(registro.id))

    hours_repo.eliminar(registro.id)
    project_repo.desasignar_empleado(project_id, emp_id)
    emp_repo.eliminar(emp_id)
    project_repo.eliminar(project_id)
    dept_repo.eliminar(dept_id)
    print("Prueba CRUD finalizada; datos de demostración eliminados.")


if __name__ == "__main__":
    try:
        inicializar()
        if "--demo" in sys.argv:
            demostracion_crud()
        else:
            ejecutar_menu()
    except (ValueError, TypeError) as error:
        print(f"Dato inválido: {error}")
    except sqlite3.Error as error:
        print(f"Error de base de datos: {error}")
