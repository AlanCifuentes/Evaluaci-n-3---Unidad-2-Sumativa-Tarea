from datetime import date
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from uuid import uuid4
from unittest.mock import patch

import infraestructura.conexion as db
from dominio.departamento import Departamento
from dominio.empleado import Empleado, normalizar_rut
from dominio.proyecto import Proyecto
from dominio.registro_horas import RegistroHoras
from main import leer_salario
from infraestructura.departamento_repositorio import DepartamentoRepositorio
from infraestructura.empleado_repositorio import EmpleadoRepositorio
from infraestructura.proyecto_repositorio import ProyectoRepositorio
from infraestructura.registro_horas_repositorio import RegistroHorasRepositorio


class EcoTechTests(unittest.TestCase):
    def setUp(self):
        self.tmp = TemporaryDirectory()
        self.old_db_path = db.DB_PATH
        db.DB_PATH = Path(self.tmp.name) / "test.sqlite"
        with db.obtener_conexion() as conn:
            db.crear_tablas(conn)
        self.dept_repo = DepartamentoRepositorio()
        self.employee_repo = EmpleadoRepositorio()
        self.project_repo = ProyectoRepositorio()
        self.hours_repo = RegistroHorasRepositorio()

    def tearDown(self):
        db.DB_PATH = self.old_db_path
        self.tmp.cleanup()

    def create_entities(self):
        key = uuid4().hex[:10]
        dept = Departamento(f"d-{key}", "Operaciones")
        self.dept_repo.guardar(dept)
        employee = Empleado("12.345.678-5", "Ana Rojas", "Av. Central 123",
                            "+56 9 1234 5678", "ana@ecotech.cl", date(2026, 1, 10),
                            950000.0, dept.id)
        self.employee_repo.guardar(employee)
        dept.gerente = employee
        self.dept_repo.establecer_gerente(dept.id, employee.id)
        project = Proyecto(f"p-{key}", "Paneles solares", "Instalación", date(2026, 2, 1))
        self.project_repo.guardar(project)
        self.project_repo.asignar_empleado(project.id, employee.id)
        record = RegistroHoras(None, date(2026, 2, 2), 8, "Instalación", employee.id, project.id)
        self.hours_repo.guardar(record)
        return dept, employee, project, record

    def test_crud_and_relationships(self):
        dept, employee, project, record = self.create_entities()
        loaded_employee = self.employee_repo.obtener(employee.id)
        self.assertEqual(loaded_employee.get_id(), employee.id)
        self.assertEqual(loaded_employee.calcular_horas_totales(), 8)
        self.assertTrue(loaded_employee.validar_contacto())
        self.assertEqual(self.dept_repo.obtener(dept.id).contar_empleados(), 1)
        self.assertEqual(self.project_repo.obtener(project.id).contar_empleados_asignados(), 1)
        self.assertEqual(len(self.hours_repo.listar(empleado_id=employee.id)), 1)

        loaded_employee.salario = 980000.0
        self.assertEqual(self.employee_repo.actualizar(loaded_employee), 1)
        record.horas_trabajadas = 7
        self.assertEqual(self.hours_repo.actualizar(record), 1)
        project.nombre = "Proyecto actualizado"
        self.assertEqual(self.project_repo.actualizar(project), 1)
        dept.nombre = "Departamento actualizado"
        self.assertEqual(self.dept_repo.actualizar(dept), 1)

        self.assertTrue(self.hours_repo.eliminar(record.id))
        self.assertTrue(self.project_repo.desasignar_empleado(project.id, employee.id))
        self.assertTrue(self.employee_repo.eliminar(employee.id))
        self.assertTrue(self.project_repo.eliminar(project.id))
        self.assertTrue(self.dept_repo.eliminar(dept.id))

    def test_composition_cascades_employee_records(self):
        dept, employee, project, record = self.create_entities()
        self.assertTrue(self.employee_repo.eliminar(employee.id))
        self.assertIsNone(self.hours_repo.obtener(record.id))
        self.assertIsNotNone(self.project_repo.obtener(project.id))
        self.project_repo.eliminar(project.id)
        self.dept_repo.eliminar(dept.id)

    def test_aggregation_preserves_records_if_project_deleted(self):
        dept, employee, project, record = self.create_entities()
        self.assertTrue(self.project_repo.eliminar(project.id))
        loaded_record = self.hours_repo.obtener(record.id)
        self.assertIsNotNone(loaded_record)
        self.assertIsNone(loaded_record.proyecto_id)
        self.assertEqual(self.employee_repo.obtener(employee.id).calcular_horas_totales(), 8)
        self.employee_repo.eliminar(employee.id)
        self.dept_repo.eliminar(dept.id)

    def test_invalid_values_are_rejected(self):
        empleado_invalido = Empleado(
            "12.345.678-5", "Ana", "Dirección", "teléfono inválido", "no-es-email",
            date.today(), 1000.0, "d-1"
        )
        self.assertFalse(empleado_invalido.validar_contacto())
        with self.assertRaises(TypeError):
            RegistroHoras(None, date.today(), 2.5, "Tarea", "12.345.678-5", "p-1")
        with self.assertRaises(ValueError):
            RegistroHoras(None, date.today(), 0, "Tarea", "12.345.678-5", "p-1")

    def test_rut_formats_are_normalized_and_check_digit_is_checked(self):
        self.assertEqual(normalizar_rut("12.345.678-5"), "12345678-5")
        self.assertEqual(normalizar_rut("123456785"), "12345678-5")
        self.assertEqual(normalizar_rut("12.345.6785"), "12345678-5")
        with self.assertRaises(ValueError):
            normalizar_rut("12345678-7")

    def test_salary_rejects_decimal_or_grouping_punctuation(self):
        with self.assertRaises(ValueError):
            Empleado("12.345.678-5", "Ana", "Dirección", "+56912345678",
                     "ana@ecotech.cl", date.today(), 950000.5, "d-1")
        with patch("builtins.input", return_value="950.000"):
            with self.assertRaises(ValueError):
                leer_salario("Salario: ")
        with patch("builtins.input", return_value="950000"):
            self.assertEqual(leer_salario("Salario: "), 950000.0)


if __name__ == "__main__":
    unittest.main()
