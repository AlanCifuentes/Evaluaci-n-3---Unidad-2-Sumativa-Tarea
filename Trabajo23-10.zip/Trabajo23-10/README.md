# EcoTech Solutions — base de implementación ES2

Versión de trabajo alineada al UML compartido: Empleado, Departamento, Proyecto y RegistroHoras.

## Ejecutar

```bash
python main.py
```

Para ejecutar la demostración automática del CRUD:

```bash
python main.py --demo
```

El modo normal presenta un menú para ingresar y gestionar datos; `sqlite3` viene incluida en Python y la base `ecotech_validada.db` se crea en la carpeta raíz. Se usa un nombre nuevo para no mezclarla con una `ecotech.db` anterior. El modo `--demo` usa identificadores únicos y elimina sus datos al terminar.

## Correspondencia con el UML

- `dominio/`: clases y comportamiento de las cuatro entidades.
- `infraestructura/conexion.py`: esquema SQLite y claves foráneas.
- `*_repositorio.py`: persistencia y operaciones CRUD.
- La relación Departamento–Empleado se almacena mediante `empleado.departamento_id`.
- La relación muchos-a-muchos Empleado–Proyecto se almacena en `empleado_proyecto`.
- RegistroHoras guarda las referencias a empleado y proyecto. La clave foránea del empleado usa `ON DELETE CASCADE` (composición); la del proyecto usa `ON DELETE SET NULL` (agregación: conserva el registro si se elimina el proyecto).

## Supuestos que deben revisar con el equipo/docente

- `Empleado.id` se usa como RUT, normalizado a `12345678-5` (sin puntos, con guion) y con validación del dígito verificador. Se acepta el RUT con o sin puntos/guion y se guarda en forma canónica.
- El salario se guarda como `float` para corresponder al tipo `Double` del UML, pero la entrada del menú exige pesos enteros sin separadores ni decimales; por ejemplo, escribe `950000`, no `950.000`.
- El UML indica horas enteras, por eso `horas_trabajadas` rechaza decimales.
- `RegistroHoras.id` se genera como texto UUID.
- El programa es una base de trabajo, no una entrega final. Revisen el código y los supuestos con el equipo/docente, y completen lo que indique el instrumento de evaluación.

## Pruebas automatizadas

```bash
python -m unittest discover -s tests -v
```

Las pruebas cubren CRUD, relaciones, validaciones y los comportamientos elegidos para composición/agregación. Esta base fue desarrollada con asistencia de IA y probada; revisa y adapta cada parte, y registra de forma honesta tus consultas, decisiones y pruebas en `docs/registro_ia_plantilla.md`. La defensa individual sigue siendo responsabilidad de cada integrante.
