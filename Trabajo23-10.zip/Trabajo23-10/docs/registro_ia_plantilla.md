# Registro personal de uso y validación de IA

Completa esta plantilla con tu uso real de herramientas; no inventes consultas ni resultados.

| Fecha y herramienta | Qué pedí / prompt utilizado | Qué fragmento o idea sugirió | Revisión técnica propia | Decisión y cambios realizados | Prueba ejecutada y resultado |
|---|---|---|---|---|---|
| Oct 2026 – Grok / ChatGPT | Ayuda para implementar normalizar_rut con dígito verificador chileno | Algoritmo de cálculo del DV y manejo de formatos con/sin puntos | Coherencia con UML, validación de seguridad (no inyección), eficiencia | Acepté el algoritmo, lo ajusté para devolver forma canónica y lanzar ValueError claros | test_rut_formats_are_normalized... → OK |
| Oct 2026 – Grok | Estructura de repositorios con mapeo fila → objeto | Métodos _fila_a_empleado y carga de relaciones | Modularidad, SRP, no SQL en dominio | Acepté el patrón Repository + mapper centralizado | test_crud_and_relationships → OK |
| Oct 2026 – Grok | Context manager para conexión SQLite con commit/rollback | @contextmanager obtener_conexion | Atomicidad, manejo de excepciones | Acepté e integré; cualquier excepción hace rollback | Prueba manual de fallo a mitad de operación → BD consistente |
| Oct 2026 – Grok | Sugerencia de consultas con f-strings | execute(f"SELECT ... WHERE id = '{id}'") | Seguridad (SQL Injection) | Descarté completamente; reemplacé por execute(..., (id,)) | Payload ' OR '1'='1 no produce resultados indebidos |

## Preguntas para preparar la defensa

- ¿Qué partes del código recibieron apoyo de IA?  
  Principalmente el algoritmo de RUT, el esqueleto de los repositorios y el context manager de conexión.

- ¿Qué problema o error encontraste al revisar la sugerencia?  
  La IA propuso concatenación de SQL (riesgo de inyección) y en un momento sugirió herencia innecesaria (clase Gerente).

- ¿Qué cambiaste y qué criterio técnico aplicaste?  
  Eliminé todo f-string/concatenación → consultas 100 % parametrizadas (seguridad). Mantuve ausencia de herencia para roles (coherencia con UML de ES1).

- ¿Qué prueba demuestra que el cambio funciona?  
  Las pruebas unitarias de RUT, CRUD, composición (cascada) y agregación, más la verificación manual de que un payload de inyección no altera el resultado.
